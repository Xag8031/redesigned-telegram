var Config = {
	debug: 			false,
	tweet: 			true,
	barph: 			true
};